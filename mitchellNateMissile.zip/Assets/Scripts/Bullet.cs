using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    Vector2 mousePos;
    public GameObject explode;


    public Vector2 MousePos { get => mousePos; set => mousePos = value; }


    // Start is called before the first frame update
    void Start()
    {



    }

    // Update is called once per frame
    void Update()
    {
        if (Mathf.Abs(mousePos.x) <= Mathf.Abs(transform.position.x) && mousePos.y <= transform.position.y)
        {

            Instantiate(explode, transform.position, transform.rotation);
            Destroy(gameObject);
        }


    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("cities"))
        {

            Destroy(gameObject);
        }
    }

}
