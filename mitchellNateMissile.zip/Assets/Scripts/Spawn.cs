using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour
{
    public GameObject Enemy;
    public float ypos;
    public float xpos;
    bool waitTime;
    public int enemycount;
    public GameObject[] cityList;
    public int cityNo;
    
   

    // Start is called before the first frame update
    void Start()
    {
        
        StartCoroutine(SpawnEnemy());
        cityList = GameObject.FindGameObjectsWithTag("cities");
   
    }

    // Update is called once per frame
    IEnumerator SpawnEnemy()
    {
        while (enemycount < 100)
        {
            if (waitTime == false)
            {
                yield return new WaitForSeconds(3.0f);
                waitTime = true;
            }
            else
            {
                GameObject targetCity = null;
                xpos = Random.Range(-10f, 10f);
                while (targetCity == null) 
                {
                    
                    cityNo = Random.Range(0, 6);
                    targetCity = cityList[cityNo];
                }
                
               
                GameObject missile = Instantiate(Enemy, new Vector2(xpos, 6f), Quaternion.identity);
                missile.GetComponent<Missile>().target = targetCity;
                yield return new WaitForSeconds(5.0f);


                enemycount += 1;
                enemycount -= 1;
            }
        }
    }
   
    void Update()
    {
        int numFind = 0;
        for (int i = 0; i<= 5; i ++)
        {
            if (cityList[i] == null)
            {
                numFind++;
            }
            if (numFind == 6) 
            {
                UnityEngine.SceneManagement.SceneManager.LoadScene(0);
            }
        }
    
      
    }
}
