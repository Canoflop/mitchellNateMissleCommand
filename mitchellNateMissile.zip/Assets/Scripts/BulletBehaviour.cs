using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletBehaviour : MonoBehaviour
{
    public Transform firepoint;
    public GameObject bulletObject;
    public float time = 2.0f;
    public float timer;
    Vector2 mousePos;
    public Camera cam;
    public float bulletSpeed = 5f;
    // Start is called before the first frame update
    private void Awake()
    {
        timer = Time.time;
    }

    // Update is called once per frame
    void Shoot()
    {
        GameObject bullet = Instantiate(bulletObject, firepoint.position, firepoint.rotation);
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        rb.AddForce(firepoint.up * bulletSpeed, ForceMode2D.Impulse);

        mousePos = cam.ScreenToWorldPoint(Input.mousePosition);

        bullet.GetComponent<Bullet>().MousePos = mousePos;
        

        
    }
    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= time)
        {

            if (Input.GetKey(KeyCode.Mouse0))
            {
                Shoot();
                timer = 1.5f;
                Debug.Log("shooting");

                
            }
        }

    }
    


}
